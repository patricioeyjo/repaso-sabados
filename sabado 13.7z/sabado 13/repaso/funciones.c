#include "Funciones.h"
/*
* \brief Solicito un numero al usuario y lo retorno.
* \param Numero que desea ingresar el usuario.
* \return El numero ingresado por el usuario.
*/
int PedirUnNumero(int auxiliar)
    {

    printf("ingrese un numero:  ");
    scanf("%d",&auxiliar);

    return auxiliar;
    }

/*
* \brief Recibe los numeros ingresados por el usuario y calcula la suma de estos.
* \param x: es el primer numero ingresado.
* \param y: es el segundo numero ingresado.
* \param resultado: representa la suma de x e y.
* \return el resultado de la suma.
*/

int suma(int x, int y)
    {

    int resultado;
    resultado=x+y;

    return resultado;
    }

/*
* \brief Recibe los numeros ingresados por el usuario y calcula la resta de estos.
* \param x: es el primer numero ingresado.
* \param y: es el segundo numero ingresado.
* \param resultado: en este caso representa la resta de x e y
* \return el resultado de la resta.
*/
int resta(int x, int y)
    {

    int resultado;
    resultado=x-y;

    return resultado;
    }

/*
* \brief Recibe los numeros ingresados por el usuario y calcula la multiplicacion de estos.
* \param x: es el primer numero ingresado.
* \param y: es el segundo numero ingresado.
* \param resultado: en este caso representa la multiplicacion de x e y
* \return el resultado de la multiplicacion.
*/
int multiplicacion(int x, int y)
    {

    int resultado;
    resultado=x*y;

    return resultado;
    }

/*
* \brief Recibe los numeros ingresados por el usuario y calcula la division de estos.
* \param x: es el primer numero ingresado.
* \param y: es el segundo numero ingresado.
* \param resultado: en este caso representa la division de x e y
* \return el resultado de la division(resultado de tipo float).
*/
float division(int x, int y)
    {
        if(x==0 || y==0)
            {
                return 00;
            }

    float resultado;
    resultado=(float)x/y;


    return resultado;
    }
/*
* \brief Recibe el primer numero ingresado por el usuario y retorna su factorial
* \param x: es el primer numero ingresado
* \param resultado: en este caso representa el factorial del primer numero ingresado
* \return factorial de x, si el numero es menor a cero retorna cero
*/
int factorial(int x)
    {
    int resultado;
    if(x<0)
    return 0;
    if(x==0)
    return 1;
    resultado=x* factorial(x-1);
    return resultado;
}


/*
* \brief Recibe los numeros ingresados por el usuario y calcula todas las operaciones.
* \param x: es el primer numero ingresado.
* \param y: es el segundo numero ingresado.
* \return el resultado de todas las operaciones
*/
void todasLasOperaciones(int x, int y)
    {
         printf("\nresultado de la suma: %d\n",suma(x,y));
         printf("\nresultado de la resta: %d\n",resta(x,y));
         printf("\nresultado de la multiplicacion: %d\n",multiplicacion(x,y));
         if(division(x,y)==00)
                 {
                    printf("\nNo se pudo dividir por 0\n");
                 }
                 else
                 {
                     printf("\nresultado de la division: %.2f\n",(division(x,y)));
                 }
         printf("\nfactorial: %d\n",factorial(x));
    }
