#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
/*
*solicita un numero entero
*/
int PedirUnNumero(int);


/*
*suma dos numeros enteros
*/
int suma(int x, int y);

/*
*resta dos numeros enteros
*/
int resta(int x, int y);

/*
*multiplica dos numeros enteros
*/
int multiplicacion(int x, int y);

/*
*divide dos numeros enteros y da el resultado flotante
*/
float division(int x, int y);

/*
*calcula el factorial de un numero
*/
int factorial(int x);

/*
*calcula todas las operaciones
*/
void todasLasOperaciones(int x, int y);


#endif // FUNCIONES_H_INCLUDED
