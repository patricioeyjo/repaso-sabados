#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAMANIO 3
int getPrecio(char*mensaje,float*elPrecio);
int getCodigo(char *mensaje,char *codigo);
int main()
{
    float precios[TAMANIO];
    char mensaje;
    char codigos[TAMANIO][5];
    int i;
    int j;

    for(i=0; i<TAMANIO; i++)
    {

        while(getPrecio("ingrese precio ",&precios[i])==0)
        {
            printf("error... \n");
        }
            while(getCodigo("ingrese codigo ",&codigos[i])==0)
            {
            printf("error... \n");
            }
    }
     for(i=0; i<TAMANIO; i++)
     {
        printf("codigo: %s \nprecio: %f \n",codigos[i],precios[i]);
     }
     for(i=0;i<TAMANIO;i++)
        {
        for(j=0;j<TAMANIO-1;i++)
            {
            if(precios[i]<precios[j])
                {
                int aux=precios[i];
                precios[i]=precios[j];
                precios[j]=aux;

                char auxCodigo[7];
                strcpy(auxCodigo,codigos[i]);
                strcpy(codigos[i],codigos[j]);
                strcpy(codigos[j],auxCodigo);
                }
            }
        }



    return 0;
}

int getPrecio(char*mensaje,float*elPrecio)
{
    int retorno=0;
    float auxPrecio;
    char ingreso[50];

    printf(mensaje);
    scanf("%s",ingreso);
    auxPrecio=atof(ingreso);
        if(auxPrecio>0)
        {
            *elPrecio=auxPrecio;
            retorno=1;
        }
    return retorno;
}
int getCodigo(char *mensaje,char *codigo)
{
 char ingreso[50];
 int retorno=0;
 printf(mensaje);
 scanf("%s",ingreso);
 if(strlen(ingreso)==6)
    {
    strcpy(codigo,ingreso);
    retorno=1;
    }
 return retorno;
}
