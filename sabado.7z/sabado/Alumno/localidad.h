#ifndef LOCALIDAD_H_INCLUDED
#define LOCALIDAD_H_INCLUDED
typedef struct
{
    int Id;
    int localidad;
    int estado;
}eLocalidad;

void inicializarLocalidad(eLocalidad localidades[],int tam);
int buscarLocalidadLibre(eLocalidad[],int tam);
int buscarLocalidad(eLocalidad localidades[], int tam, int Id,int localidad);

#endif // LOCALIDAD_H_INCLUDED
