#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "localidad.h"
#include "alumno.h"
#include "utn.h"

void inicializarAlumno(eAlumno alumnos[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

        alumnos[i].estado= 0;

    }
}

int buscarAlumnoLibre(eAlumno alumnos[],int tam)
{
    int index;
    int i;
    for(i=0; i<tam; i++)
    {
        if (alumnos[i].estado == 0)
        {
            index = i;
            break;
        }
        else if(alumnos[i].estado ==1)
        {
            index = -1;
        }
    }
    return index;
}


int buscarAlumno(eAlumno alumnos[], int tam, int Id)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(alumnos[i].estado ==1 && alumnos[i].Id == Id)
        {
            index=i;
            break;
        }
    }

    return index;
}

void altaAlumno(eAlumno alumnos[],int tam,eLocalidad localidades[])
{
    int auxId;
    int auxLocalidad;
    int index;
    int indexLocalidad;
    int validar;


    index=buscarAlumnoLibre(alumnos,tam);

    if(index == -1)
    {
        printf("\nNo hay lugares disponibles\n");
    }
    else
    {
        printf("Ingrese localidad de alumno: ");
        scanf("%d",&auxLocalidad);
        printf("Ingrese Id de alumno: ");
        scanf("%d",&auxId);
        indexLocalidad= buscarLocalidad(localidades,tam,auxId,auxLocalidad);
        if(indexLocalidad==-1)
        {
            printf("No se encontro la localidad\n");
        }
        else
        {


                do{

                validar=getStringLetras("ingrese el nombre del alumno: ",alumnos[index].nombre);
                }while(validar==0);
                printf("ingrese el nota del alumno: ");
                scanf("%d",&alumnos[index].nota);
        }
    }


}
