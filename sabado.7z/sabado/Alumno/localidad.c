#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "localidad.h"
#include "alumno.h"
#include "utn.h"
void inicializarLocalidad(eLocalidad localidades[],int tam)
{
    int Id=1000;
    int localidad=100;
    int i;
    for(i=0; i<tam; i++)
    {
        localidades[i].Id=Id+1;
        Id++;
        localidades[i].localidad=localidad+1;
        localidad++;
        localidades[i].estado= 1;

    }
}

int buscarLocalidadLibre(eLocalidad localidades[],int tam)
{
    int index;
    int i;
    for(i=0; i<tam; i++)
    {
        if (localidades[i].estado == 0)
        {
            index = i;
            break;
        }
        else if(localidades[i].estado ==1)
        {
            index = -1;
        }
    }
    return index;
}


int buscarLocalidad(eLocalidad localidades[], int tam, int Id,int localidad)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(localidades[i].estado ==1 && localidades[i].Id == Id&& localidades[i].localidad == localidad)
        {
            index=i;
            break;
        }
    }

    return index;
}
