#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "alumno.h"
#include "localidad.h"
#include "utn.h"
#define TAM 5

int menu();

int main()
{
    eLocalidad arrayLocalidad[TAM];
    eAlumno arrayAlumno[TAM];
    inicializarAlumno(arrayAlumno);
    inicializarLocalidad(arrayLocalidad);

    char rta = 's';
    char confirma;
    do
    {
        switch(menu())
        {
        case 1:

            system("pause");
            break;
        case 2:

            system("pause");
            break;
        case 3:

            break;
        case 4:


            break;
        case 5:

            break;
        case 6:

            break;
        case 7:

            break;
        case 8:
            break;
        case 9:
        printf("Seguro desea salir? s/n \n");
        fflush(stdin);
        confirma = getch();
        if(tolower(confirma)== 's')
            {
                rta = 'n';
            }
            break;
        default:
            printf("Ingrese opcion correcta\n");
            system("pause");
        }

    }
    while(rta == 's');

    return 0;
}
int menu()
{
    int opcion;

    system("cls");
    printf("---------------ABM --------------\n");
    printf("1.Alta alumno\n");
    printf("2.Baja alumno\n");
    printf("3.Modificacion alumno\n");
    printf("4.Ordenar localidades\n");
    printf("5.Ordenar Alumnos\n");
    printf("6.Cantidad de notas mayores a 5\n");
    printf("7.La mejor nota\n");
    printf("8.La mejor nota y los nombres\n");
    printf("9.Salir\n");
    printf("Elija una opcion:");
    scanf("%d",&opcion);

    return opcion;
}
