#ifndef ALUMNO_H_INCLUDED
#define ALUMNO_H_INCLUDED
#include "localidad.h"
typedef struct
{
    char nombre[31];
    int nota;
    int Id;
    int localidad;
    int estado;
}eAlumno;

void inicializarAlumno(eAlumno alumnos[],int tam);
int buscarAlumnoLibre(eAlumno alumnos[],int tam);
int buscarAlumno(eAlumno alumnos[], int tam, int Id);
void altaAlumno(eAlumno alumnos[],int tam,eLocalidad localidades[]);

#endif // ALUMNO_H_INCLUDED
