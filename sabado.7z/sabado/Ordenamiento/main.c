#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "alumnos.h"
#define TAM 7



int main()
{
    eAlumno listaAlumnos[7];
    hardcodearAlumnos(listaAlumnos);

    informarSobreAlumno(listaAlumnos,TAM);





    return 0;
}


