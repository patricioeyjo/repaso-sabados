
typedef struct
{
    int id;
    char nombre[];

}eLocalidad;
